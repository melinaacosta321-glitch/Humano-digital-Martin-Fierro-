# Martín Fierro | El gaucho cantor

Recreación con inteligencia artificial del protagonista del poema de José Hernández (1872 y 1879). Martín Fierro no existió: el rostro se basa en un retrato de su autor, José Hernández, como préstamo visual.

## Publicarlo en GitHub Pages
1. Creá un repositorio público y subí estos archivos (**Add file → Upload files → Commit changes**).
2. En **Settings → Pages**, elegí **Deploy from a branch**, rama **main**, carpeta **/ (root)**, y tocá **Save**.
3. Abrí `https://TU_USUARIO.github.io/NOMBRE_DEL_REPO/`, tocá **Hablar** y permití el micrófono.

## El agente
- ID: `agent_4901m4w3412eem2txywgr9d07rd4`. Para usar otro sin tocar el código: `index.html?agente=TU_ID`.
- Tiene que ser **público**: en ElevenLabs, pestaña *Security*, autenticación desactivada. Si usás lista de dominios, agregá `TU_USUARIO.github.io`.

## Qué hace la figura
- Mueve la boca según cada letra que dice el agente y según el sonido real.
- Se puede girar 360°; mira a quien la rodea; gesticula al hablar.
- «Escucharlo sin conectarse» usa la voz del dispositivo, sin gastar créditos.

Necesita internet: la voz viaja por ElevenLabs y la figura usa Three.js desde jsDelivr. Cada conversación consume créditos de ElevenLabs.

## Archivos del repositorio
- `index.html`: la página del humano digital (escena con silla, mesa, libro en su posalibros, bombo, guitarra y poncho rojo con guarda pampa).
- `libro.html`: el poema completo para leer en el sitio, con índice por cantos (se abre en `https://TU_USUARIO.github.io/NOMBRE_DEL_REPO/libro.html`).
- `martin-fierro-biblioteca-del-congreso.pdf`: el poema completo (La Ida y La Vuelta), edición de la Biblioteca del Congreso de la Nación, 2022. Es la fuente del texto que usa el agente.
- `poema-completo.txt`: el mismo texto, limpio y marcado por parte y canto, tal como se cargó en ElevenLabs (en cuatro documentos).
- `base-de-conocimiento.txt` y `prompt-del-agente.txt`: la base y las instrucciones del agente.
